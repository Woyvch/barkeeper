module.exports = {
  singleQuote: true, // only use single quotes
  endOfLine: "lf", // disable cr error
};